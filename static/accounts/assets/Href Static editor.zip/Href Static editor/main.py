import re

class Hello:
    def replace_href_with_static(self, html_file_path):
        # Read the existing HTML file
        with open(html_file_path, 'r') as file:
            html_content = file.read()

        # Replace href and src attribute values
        modified_html = re.sub(
            r'(href|src)="([^"]+)"',
            lambda match: self.replace_attribute(match),
            html_content
        )

        # Write the modified HTML back to the file
        with open(r'C:\Users\subas\Desktop\index.html', 'w') as file:
            file.write(modified_html)

    def replace_attribute(self, match):
        attribute_name = match.group(1)
        attribute_value = match.group(2)
        if attribute_value == '#' or attribute_value.startswith('{% static '):
            return match.group(0)
        else:
            return attribute_name + '="{% static \'' + attribute_value + '\' %}"'

# Usage example
x = Hello()
x.replace_href_with_static(r'C:\Users\subas\Downloads\Website Templates\Templates\molla-eCommerce-html-template\login.html')
